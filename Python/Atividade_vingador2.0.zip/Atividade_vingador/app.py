# app.py
from model.interface import Interface
from model.vingador import Vingador

if __name__ == "__main__":
    Interface.menu()
