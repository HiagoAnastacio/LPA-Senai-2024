from teste import Interface
Interface.menu()